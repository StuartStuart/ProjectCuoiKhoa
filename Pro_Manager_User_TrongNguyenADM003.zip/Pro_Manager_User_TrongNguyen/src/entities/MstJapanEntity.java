/**
 * Copyright(C) 2018 	Luvina
 * MstJapanEntity.java, Aug 14, 2018, LA-PM
 */
package entities;

/**
 * @author LA-PM
 *
 */
public class MstJapanEntity {
	private String code_level;
	private String name_level;

	public String getCode_level() {
		return code_level;
	}

	public void setCode_level(String code_level) {
		this.code_level = code_level;
	}

	public String getName_level() {
		return name_level;
	}

	public void setName_level(String name_level) {
		this.name_level = name_level;
	}

}
