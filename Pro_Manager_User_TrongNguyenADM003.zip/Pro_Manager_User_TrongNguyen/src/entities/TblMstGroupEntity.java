/**
 * Copyright(C) 2018 	Luvina
 * TblMstGroupEntity.java, Aug 14, 2018, LA-PM
 */
package entities;

/**
 * @author LA-PM
 *
 */
public class TblMstGroupEntity {
	private int groupId;
	private String groupName;

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

}
