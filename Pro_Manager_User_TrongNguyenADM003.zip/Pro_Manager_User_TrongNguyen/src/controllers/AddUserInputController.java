package controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entities.MstJapanEntity;
import entities.TblMstGroupEntity;
import utils.ConstantUtil;

/**
 * Servlet implementation class AddUserInputController
 */
@WebServlet(description = "Xử lý khi click vào button Add của ADM002", urlPatterns = { "/AddUserInputController.do" })
public class AddUserInputController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			/*
			 * các giá trị cần đươc hiển thị trên ADM003
			 */
			String loginName;
			ArrayList<TblMstGroupEntity> listGroupIds;
			String fullName;
			String fullNameKana;
			ArrayList<Integer> listBirthYears;
			int[] arrBirthMonths = new int[12];
			int[] arrBirthDates = new int[12];
			String email;
			String tel;
			String pass;
			String passConfirm;
			ArrayList<MstJapanEntity> listLevels;
			ArrayList<Integer> listStartYears;
			int[] arrStartMonths = new int[12];
			int[] arrStartDates = new int[12];
			ArrayList<Integer> listEndYears;
			int[] arrEndMonths = new int[12];
			int[] arrEndDates = new int[12];
			String total;

			/*
			 * Xác định giá trị của các vùng được hiển thị
			 */
			// lựa chọn kiểu để set values
			String type = (String) request.getAttribute("type");
			if (null != type || ConstantUtil.ADM003_ADD.equals(type)) {
				setDataLogic(request, response);
//			[themvaoday]
			} else {

			}

			/*
			 * gửi các giá trị lên request và chuyển đến màn hình ADM003
			 */
			// send values
			request.setAttribute("adm003loginname", loginName);
			request.setAttribute("adm003listgroupids", listGroupIds);
			request.setAttribute("adm003listfullname", fullName);
			request.setAttribute("adm003listfullnamekana", fullNameKana);
			request.setAttribute("adm003listbirthyears", listBirthYears);
			request.setAttribute("adm003arrbirthmonths", arrBirthMonths);
			request.setAttribute("adm003arrbirthdates", arrBirthDates);
			request.setAttribute("adm003email", email);
			request.setAttribute("adm003tel", tel);
			request.setAttribute("adm003pass", pass);
			request.setAttribute("adm003passconfirm", passConfirm);
			request.setAttribute("adm003listlevels", listLevels);
			request.setAttribute("adm003liststartyears", listStartYears);
			request.setAttribute("adm003arrstartmonths", arrStartMonths);
			request.setAttribute("adm003arrstartdates", arrStartDates);
			request.setAttribute("adm003listendyears", listEndYears);
			request.setAttribute("adm003arrendmonths", arrEndMonths);
			request.setAttribute("adm003arrenddates", arrEndDates);
			request.setAttribute("adm003total", total);
			// chuyển đến ADM003
			request.getRequestDispatcher("jsp/ADM003.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("jsp/System_Error.jsp");
		}
	}

	/**
	 * Thực hiện set giá trị cho các hạng mục selectbox ở màn hình ADM003
	 * 
	 * @param request
	 * @param response
	 */
	private void setDataLogic(HttpServletRequest request, HttpServletResponse response) {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public static void main(String[] args) {
		String str = null;
		if ("".equals(str)) {
			System.out.println("OK");
		} else {
			System.out.println("NO");
		}
	}
}
