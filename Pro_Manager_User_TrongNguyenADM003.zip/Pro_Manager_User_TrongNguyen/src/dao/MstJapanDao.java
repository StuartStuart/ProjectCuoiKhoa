/**
 * Copyright(C) 2018 	Luvina
 * MstJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package dao;

/**
 * đối tượng MstJapanDao
 * @author TrongNguyen
 *
 */
public interface MstJapanDao{

}
