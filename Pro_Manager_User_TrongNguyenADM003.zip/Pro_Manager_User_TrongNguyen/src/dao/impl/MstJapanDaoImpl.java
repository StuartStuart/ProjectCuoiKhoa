/**
 * Copyright(C) 2018 	Luvina
 * MstJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package dao.impl;

import dao.MstJapanDao;

/**
 * đối tượng MstJapanDao
 * 
 * @author TrongNguyen
 *
 */
public class MstJapanDaoImpl extends BaseDaoImpl implements MstJapanDao {
}
