/**
 * Copyright(C) 2018 	Luvina
 * MstJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package logics.impl;

import logics.MstJapanLogic;

/**
 * đối tượng MstJapanLogic
 * @author TrongNguyen
 *
 */
public class MstJapanLogicImpl implements MstJapanLogic{

}
