/**
 * Copyright(C) 2018 	Luvina
 * TblDetailUserJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package logics.impl;

import logics.TblDetailUserJapanLogic;

/**
 * đối tượng TblDetailUserJapanLogic
 * @author TrongNguyen
 *
 */
public class TblDetailUserJapanLogicImpl implements TblDetailUserJapanLogic{

}
