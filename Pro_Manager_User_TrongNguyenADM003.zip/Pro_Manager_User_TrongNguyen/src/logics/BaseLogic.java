/**
 * Copyright(C) 2018	Luvina
 * BaseLogic.java, Aug 16, 2018, A
 */
package logics;

/**
 * Chỉ bao gồm phương thức khởi tạo init()
 * 
 * @author A
 *
 */
public interface BaseLogic {
	void init();
}
