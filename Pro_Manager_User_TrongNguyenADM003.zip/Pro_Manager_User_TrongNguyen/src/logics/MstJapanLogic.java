/**
 * Copyright(C) 2018 	Luvina
 * MstJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package logics;

/**
 * đối tượng MstJapanLogic
 * @author TrongNguyen
 *
 */
public interface MstJapanLogic {

}
