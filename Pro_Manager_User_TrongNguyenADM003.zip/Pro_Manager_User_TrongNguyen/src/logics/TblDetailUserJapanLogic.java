/**
 * Copyright(C) 2018 	Luvina
 * TblDetailUserJapanDao.java, Aug 13, 2018, TrongNguyen
 */
package logics;

/**
 * đối tượng TblDetailUserJapanLogic
 * @author TrongNguyen
 *
 */
public interface TblDetailUserJapanLogic {

}
