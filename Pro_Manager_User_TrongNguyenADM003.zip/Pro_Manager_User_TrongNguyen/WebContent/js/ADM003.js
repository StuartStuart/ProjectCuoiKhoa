/**
 * trở lại màn hình ADM002
 */
function backADM002() {
	window.location = "../ListUser.do?type=back";
}
/**
 * hiện, ẩn vùng trình độ tiếng Nhật
 */
function hideJapanLevel() {
	var zoneJapanese = document.getElementById("adm003hiddenshow");
	if (zoneJapanese.style.display == 'none') { // là trạng thái ko hiển thị
		zoneJapanese.style.display = 'table-row-group';
	} else {
		zoneJapanese.style.display = 'none';
	}
}